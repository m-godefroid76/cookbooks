default['wordpress']['db']['name'] = "wordpress"
default['wordpress']['db']['user'] = "root"
default['wordpress']['db']['pass'] = nil
default['wordpress']['db']['host'] = "localhost"
default['wordpress']['db']['charset'] = "utf8"
default['wordpress']['db']['prefix'] = "wp_"
default['wordpress']['lang'] = "zh_TW"

default['wordpress']['keys']['auth'] = nil
default['wordpress']['keys']['secure_auth'] = nil
default['wordpress']['keys']['logged_in'] = nil
default['wordpress']['keys']['nonce'] = nil
default['wordpress']['salt']['auth'] = nil
default['wordpress']['salt']['secure_auth'] = nil
default['wordpress']['salt']['logged_in'] = nil
default['wordpress']['salt']['nonce'] = nil

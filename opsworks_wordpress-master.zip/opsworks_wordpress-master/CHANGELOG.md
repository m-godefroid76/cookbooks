# 0.1.0

Initial release of opsworks_wordpress
